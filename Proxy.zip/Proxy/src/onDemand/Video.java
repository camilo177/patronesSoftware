package onDemand;

// 1. Interfaz que define la funcionalidad de un video
interface Video {
    void play();
}